# My First Project > 2025-11-30 2:21pm
https://universe.roboflow.com/myworkspase-c25jb/my-first-project-nbkin

Provided by a Roboflow user
License: CC BY 4.0

